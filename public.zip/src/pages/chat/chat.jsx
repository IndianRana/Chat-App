import React from 'react'
import './chat.css'

const chat = () => {
  return (
    <div>
        We are on the chat page
    </div>
  )
}

export default chat