import React from 'react'
import './ProfileUpdate.css'

const ProfileUpdate = () => {
  return (
    <div>
        We are the profile page
    </div>
  )
}

export default ProfileUpdate