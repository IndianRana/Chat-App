import React from 'react'
import './login.css'

const login = () => {
  return (
    <div>
        We are on the login page
    </div>
  )
}

export default login