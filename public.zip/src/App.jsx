import react from 'react'
import { Route, Routes } from 'react-router-dom'
import login from './pages/login/login'
import chat from './pages/chat/chat'
import ProfileUpdate from './pages/ProfileUpdate/ProfileUpdate'

const App = () => {

  return (
    <>
       <Routes>
        <Route path='/' element={<login/>}/>
        <Route path='/chat' element={<chat/>}/>
        <Route path='/ProfileUpdate' element={<ProfileUpdate/>} />
        </Routes> 
    </>
  ) 
}

export default Apps